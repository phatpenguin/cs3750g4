﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BBQRMSSolution.Messages;
using BBQRMSSolution.ViewModels;
using Controls;

namespace $rootnamespace$
{
	//TODO: Change the type parameter to the correct type.
	//      And in the xaml file:
	//      Change the x:TypeArguments line
	//      Change the d:DesignInstance Type=ViewModels:ViewModelBase, IsDesignTimeCreateable=False
	public partial class $safeitemrootname$ : UserControlBase<ViewModelBase>
	{
		public $safeitemrootname$()
		{
			InitializeComponent();
		}
	}
}
