using System;
using System.ComponentModel;
using System.Data.Services.Client;
using System.Linq;
using BBQRMSSolution.BusinessLogic;
using BBQRMSSolution.Messages;
using BBQRMSSolution.ServerProxy;
using Controls;

namespace $rootnamespace$
{
	public class $safeitemname$ : ViewModelBase
	{
		[Obsolete("Used for design-time only", true)]
		public $safeitemname$()
		{
		}

		public $safeitemname$(BBQRMSEntities dataService, IMessageBus messageBus, ISecurityContext securityContext)
		{
			DataService = dataService;
			MessageBus = messageBus;
			SecurityContext = securityContext;
		}

		
	}
}